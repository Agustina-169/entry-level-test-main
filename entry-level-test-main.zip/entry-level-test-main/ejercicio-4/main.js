'use strict';
/**********************************************************************************************
Ejercicio 4:

El objetivo de este ejercicio es agregar funcionalidad a este prototipo de la web de "Quinto",
haciendo uso de scripts en lenguaje JavaScript, codigo HTML y CSS.

Actualmente esta terminado el maquetado de la primer version de este prototipo web,
en base al mockup 'quinto_old.jpeg'.

Vas a notar que la web actualmente esta haciendo uso de:
  - Bootstrap v4
  - PopperJS v1
  - JQuery v3.6

Se requiere que:
  - Usando como referencia el mockup/wireframe 'quinto_new.jpeg'.
  - Agregues una nueva seccion al home, destinada a mostrar distintos comentarios de los clientes:
    - Para esta nueva version del prototipo es suficiente con incluir en la vista:
      - 1: Titulo para la nueva seccion, por ejemplo: '¡Dejanos tus comentarios!'.
      - 2: Input de texto para 'nombre completo' + Input de texto para 'contenido del comentario' + boton 'Enviar'.
      - 3: Lista de comentarios enviados.
    - Podes elegir estilos y colores para darle un look mas moderno a esta nueva seccion.
  - Implementes la funcionalidad necesaria para que pueda probarse
    la siguiente interaccion por parte del usuario en el boton de 'Enviar':
    - Cada vez que se haga click en el boton 'Enviar':
      - Si hay texto en el input 'nombre completo' y al mismo tiempo
        hay texto en el input 'contenido del comentario' y este ultimo tiene un largo de 10 caracteres o mas:
        - Debe agregarse un nuevo item a la lista de comentarios enviados:
          - Este nuevo item deberia incluir:
            - Nombre de la persona que hizo el comentario.
            - Texto del comentario.
            - Fecha y hora de envio del comentario.
        - Debe mostrarse un mensaje de "exito en el envio" al usuario.
      - Si no hay texto en alguno de los campos de input,
        o si el largo del texto en 'contenido del comentario' es menor a 10 caracteres:
        - No modificar la lista de comentarios enviados.
        - Mostrar un mensaje con el error correspondiente al usuario.

PLUS (no obligatorios):
  - Si es posible, los comentarios enviados deberian persistirse localmente, para poder
    seguir viendolos entre las recargas del sitio web.
  - Esta web solo se visualiza correctamente para pantallas que tengan un ancho de 768px o mas:
    - Implementar las mejoras necesarias para que funcione en cualquier tamaño de pantalla.
 **********************************************************************************************/
