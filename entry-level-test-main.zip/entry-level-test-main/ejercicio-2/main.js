'use strict';
/**********************************************************************************************************************************
Ejercicio 2:

En este challenge vas a encontrar algunos componentes pertenecientes a un sistema legacy
que se utilizaba en uno de los primeros pasos de un proceso de poblado inicial de una base de datos de clientes.

Esta parte del sistema se encargaba de validar que esten disponibles y sean validos los suficientes datos
utilizados para crear clientes unicos de forma aleatoria. Estos datos son: Nombres, Apellidos y Años de nacimiento.

El sistema estuvo inactivo durante un tiempo y ahora se decidio volver a ponerlo en funcionamiento
en un nuevo ambiente de testing previo al pasaje a produccion en una maquina virtual.

Surgieron algunos problemas durante la exportacion de un antiguo backup del codigo fuente:
  - Algunas parte del codigo estan corruptas o funcionan incorrectamente y es necesario repararlas.
  - Algunas partes del codigo se perdieron por completo y es necesario recuperarlas.

Por suerte aun esta disponible la descripcion de las funcionalidades originales de los componentes del sistema.

Por otro lado, se cree que la funcion principal del sistema originalmente se llamaba "validarInputsParaGenerarClientesAleatorios",
pero se decidio nombrarla "fixMe" en la etapa de correcciones previa a las pruebas.

Objetivo:
  - Hacer las correcciones que sean necesarias para poder ejecutar la funcion "fixMe" sin errores.
  La funcion "fixMe" debe devolver el valor booleano 'true' al final de su ejecucion si todo funciona correctamente.

Para lograr el objetivo podria ser necesario hacer ajustes
tanto en las funciones como en los datos de input que vas a encontrar debajo.

Tene en cuenta que cada metodo pre-existente debe seguir cumpliendo con su funcionalidad original al aplicar tus modificaciones.
Una pequeña explicacion de cada funcionalidad original esta ubicada en un bloque de comentario al comienzo de cada metodo.

Si alguno de los metodos pre-existentes no posee funcionalidad o es erronea deberas implementar la logica
que consideres necesaria para cumplir con su funcionalidad original.

Los metodos pre-existentes son:
  - fixMe
  - getClientes
  - getRandomInt
  - sonSuficientes
  - calcularEdadesClientes
  - getStatus

Si lo consideras necesario tambien podes declarar otras funciones para organizar el codigo.
 **********************************************************************************************************************************/

// Estos son los arrays de datos que van a usarse como input durante las pruebas
const nombres = [
  'Samanta',
  'Rosa',
  'Olivia',
  'Jose',
  'Manuel',
  'Juan',
  'Elena',
  'Roberto',
  'Alexis',
  'Maria',
];
const apellidos = [
  'Pika',
  'Vena',
  'Alcides',
  'Perez',
  'Lopez',
  'Orna',
  'Santo',
  'Fortunato',
  'Noura',
  'Oviedo',
];
const anios = [
  1993,
  1990,
  1901,
  1981,
  1982,
  2001,
  1999,
  2005,
  1968,
  1977,
];

/**
 * Funcion principal del sistema:
 *  - Recibe los arrays de input nombres, apellidos y anios
 *  - Verifica que los inputs sean validos
 *  - Genera un array de clientes unicos y aleatorios
 *  - Verifica que el array de clientes generado sea valido
 *  - Devuelve true o false
 */
function fixMe(nombres, apellidos, anios) {
  const status = false;

  if (sonSuficientes(nombres, 10) && sonSuficientes(apellidos, 10) && sonSuficientes(anios, 10)) {
    let clientes = [];
    clientes = getClientes(nombres, apellidos);
  }

  // Estas son las unicas lineas que no podes modificar
  status = sonSuficientes(clientes) && calcularEdadesClientes(clientes) ? getStatus(clientes) : false;
  return status;
}

/**
 * Funcionalidad original:
 * 
 * Esta funcion debe devolver un array de clientes unicos
 * haciendo uso de los array de nombres, apellidos y anios como input.
 * 
 * Tip: No se deberian reutilizar nombres, apellidos ni años de nacimiento durante la ejecucion de esta funcion. (¿array.pop()?)
 */
function getClientes(nombres, apellidos, anios, cantidad = 2) {
  const arrayClientes = [];

  for (let i = 0; i < cantidad; i++) {
    const randomIndexNombres = getRandomInt(0, nombres.length);
    const randomIndexApellidos = getRandomInt(0, apellidos.length);
    const randomIndexAnios = getRandomInt(0, anios.length);
    const cliente = {
      id: 1,
      nombreCompleto: undefined,
      anioNacimiento: undefined,
      edadAproximada: undefined,
    };
    arrayClientes.push(cliente);
  }

  return arrayClientes;
}

/**
 * Funcionalidad original:
 * 
 * Esta funcion debe devolver un numero entero que
 * sea mayor o igual al input 'min' y
 * sea menor o igual al input 'max'.
 * 
 * Los input 'min' y 'max' seran unicamente numeros enteros.
 */
function getRandomInt(min, max) {
  // TODO
}

/**
 * Funcionalidad original:
 * 
 * Esta funcion debe revisar si tenemos la cantidad necesaria de objetos en un array dado.
 * 
 * Debe devolver true si el input 'array' es de tipo 'object' 
 * y la cantidad de objetos que tiene dentro es mayor o igual al input 'cantidad'.
 * 
 * Caso contrario debe devolver false.
 */
function sonSuficientes(array, cantidad = 10) {
  let status = false;

  if (array && array.length == cantidad) {
    status = true;
  }

  return status;
}

/**
 * Funcionalidad original:
 * 
 * Esta funcion debe calcular y setear la edad aproximada actual de cada cliente
 * utilizando como input unicamente su año de nacimiento.
 * 
 * Tip: Esta funcion deberia funcionar correctamente tambien en años futuros, sin necesidad de hacerle nuevas modificaciones.
 */
function calcularEdadesClientes(clientes) {
  let status = true;

  const anioActual = '2020';
  clientes.forEach(c => {
    c.edadAproximada = anioActual - c.anioNacimiento;
  });

  return status;
}

/**
 * Funcionalidad original:
 * 
 * Esta funcion debe obtener el status final al verificar que:
 * 
 * - No existan clientes que compartan mismo id.
 * - No existan clientes que posean un id menor o igual a 0.
 * - No existan clientes que compartan mismo nombre o mismo apellido en el array.
 * - No existan clientes que compartan misma edad en el array.
 * - No existan clientes invalidos (que posean algun campo vacio, null o undefined) en el array.
 * - No existan clientes con una edad mayor a 99 años en el array.
 * - No existan clientes con una edad menor a 18 años en el array.
 * - No existan clientes cuyo nombre completo NO sea un string.
 * - No existan clientes cuyo id, año de nacimiento y/o edad aproximada NO sean valores de tipo 'number'.
 */
function getStatus(clientes) {
  let status = true;

  if (clientes) {
    clientes.forEach(c => {
      if (c.edadAproximada > 99 || c.edadAproximada < 18) {
        let status = false;
      }
    });
  }

  return status;
}
