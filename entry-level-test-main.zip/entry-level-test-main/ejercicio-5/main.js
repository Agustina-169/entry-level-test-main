'use strict';
/************************************************************************************************
Ejercicio 5:

Este es un prototipo de un modulo perteneciente a un sistema de gestion de ordenes, clientes y productos
que sera utilizado a diario en distintas tiendas online por sus respectivos administradores.

Este modulo se encarga unicamente de mostrar (read-only) el listado de ordenes que corresponda cada dia.
El backend decide que ordenes corresponde mostrar para cada momento del dia.

El administrador de cada tienda es responsable de tomar las acciones que considere necesarias sobre las ordenes, cliente o productos,
en los modulos correspondientes, luego de haber consultado la informacion que este componente le provee.

El objetivo de este ejercicio es permitirle al administrador que use la web lo siguiente:
- Al visitar el sitio pueda ver facilmente el estado de validez de las ordenes que estan
pendientes de ser procesadas actualmente en su tienda:
  - Deberian mostrarse una debajo de la otra con un estilo de 'card':
    - Cada una debe mostrar su detalle: incluyendo datos de la orden, del customer y de los productos comprados.
      - Es requerido que los valores en moneda mostrados tengan aplicado el siguiente formato de ejemplo: 'ARS 1.234,56'
    - Cada card debe mostrar al pie un tilde/check si la orden es valida o un warning/cruz si la orden es invalida.
- Para decidir si una orden es valida o no, se deberan aprobar estas condiciones:
  - Comprobar que el monto total persistido en la orden coincide (con una precision de dos decimales)
  con el total recalculado a partir de los datos:
    - Precios y cantidades de los productos comprados.
    - Descuentos aplicados.
    - Costo de envio si corresponde.
  - Dentro del array de productos de una orden en particular no puede encontrarse dos veces un mismo SKU.
  - Las fechas created_at, shipped_at o closed_at de la orden no pueden ser futuras (posteriores al dia de hoy).
  - El customer asociado a la orden debe tener un email no nulo.

Para consultar las ordenes pendientes de verificacion en el sistema
deberas enviar un GET request a https://www.lerenconsulting.com/test/orders

Este endpoint corresponde a un sistema que expone una API de estilo REST
y hace uso del formato JSON para el envio y recepcion de informacion.
No se requiere de autenticacion para este caso de uso.
No se requiere hacer envio de ningun parametro para este caso de uso.

Algunas convenciones importantes que vas a encontrar son:
  - Los id de los objetos se encuentran persistidos como numeros enteros.
  - Los tipos de moneda se encuentran persistidos en formato ISO 4217 (https://en.wikipedia.org/wiki/ISO_4217).
  - Los valores de moneda se encuentran persistidos como strings con una precision de 2 decimales.
  - Las fechas se encuentran persistidas en formato ISO 8601 (https://en.wikipedia.org/wiki/ISO_8601).
  - Los codigos de pais se encuentran persistidos en formato ISO 3166-1 (https://en.wikipedia.org/wiki/ISO_3166-1)
  - Cada objeto "order" posee estos campos:
    - id - Identificador unico de la orden
    - customer - Objeto "customer"
    - currency - Tipo de moneda
    - subtotal - Costo de la orden antes de aplicar descuentos y antes de sumar el costo de envio
    - total - Costo final de la orden (subtotal - descuentos + costo de envio)
    - discount_coupon - Cupon de descuento utilizado en la orden (si se aplico uno)
    - discount - Valor total de descuentos si corresponde, aplicado sobre el subtotal de la orden
    - products - Array de objetos "product"
    - status - Estado general de la orden, posibles: "open", "closed" o "cancelled"
    - payment_status - Estado del pago de la orden, posibles: "authorized", "pending", "paid", "abandoned", "refunded" o "voided"
    - shipping_status - Estado del envio/retiro de la orden, posibles: "unpacked", "fulfilled" o "unfulfilled"
    - shipping_pickup_type - Tipo de envio/retiro utilizado para la orden, posibles: "ship" o "pickup"
    - shipping_cost - Valor del envio que paga el cliente
    - created_at - Fecha de creacion de la orden
    - shipped_at - Fecha de envio/retiro de la orden
    - closed_at - Fecha de cierre de la orden
  - Cada objeto "customer" posee estos campos:
    - id - Identificador unico del cliente
    - name - Nombre completo del cliente
    - email - Email del cliente
    - shipping_address - Direccion de envio del cliente
    - shipping_country - Codigo de pais del cliente
    - active - Estado actual del cliente
  - Cada objeto "product" posee estos campos:
    - id - Identificador unico del producto
    - SKU - Identificador unico del producto en deposito
    - name - Nombre / Descripcion del producto
    - quantity - Cantidad comprada
    - price - Precio unitario del producto al momento de la compra
    - free_shipping - Indica si el producto tiene envio gratis o no
    - weight - Peso del producto al momento de la compra
    - width - Ancho del producto al momento de la compra
    - height - Alto del producto al momento de la compra
    - depth - Profundidad del producto al momento de la compra
 ************************************************************************************************/

// TODO: Codigo necesario para obtener las ordenes pendientes desde el endpoint de la API mencionado anteriormente.
// Tip - Podes ubicar tu funcionalidad en el evento document ready o el evento window onload

/**
 * Este es un metodo que podes usar como utility o helper.
 * Podes escribir tu propia implementacion o modificar esta si asi lo deseas.
 * 
 * La funcion se encarga de mostrar en la vista las ordenes que recibe como input.
 * 
 * Debes usar como input un array de ordenes previamente procesadas.
 * 
 * Las ordenes que componen el array de input deberian tener estos campos obligatorios:
 *  - id
 *  - isValid (donde se indique con 'true' o 'false' si la orden paso con exito el proceso de verificacion)
 *  - moneda (currency)
 *  - subtotal
 *  - descuento (discount)
 *  - cupon (discount_coupon)
 *  - total
 *  - estado (status)
 *  - estadoPago (payment_status)
 *  - array 'productos' compuesto de objetos con estos campos obligatorios:
 *    - id
 *    - SKU
 *    - nombre (name)
 *    - cantidad (quantity)
 *    - precio (price)
 *    - envio_gratis (free_shipping)
 *  - objeto 'cliente' con estos campos obligatorios:
 *    - id
 *    - nombre (name)
 *    - email
 *    - estado (active)
 *  - objeto 'envioRetiro' con estos campos obligatorios:
 *    - tipo (shipping_pickup_type)
 *    - costo (shipping_cost)
 *    - estado (shipping_status)
 */
const mostrarOrdenes = (ordenesProcesadas) => {
  if (ordenesProcesadas && ordenesProcesadas.length > 0) {
    $(`.ordenes_title`).text(ordenesProcesadas.length + ' ' + $(`.ordenes_title`).text());
    $(`.section_ordenes`).html(``);
    for (let i = 0; i < ordenesProcesadas.length; i++) {
      const orden = ordenesProcesadas[i];
      const cliente = orden.cliente;
      const clienteDomElement = `
        <h5 class="card-title">Datos del cliente #${cliente.id}</h5>
        <ul>
          <li><b>Nombre:</b> ${cliente.nombre}</li>
          <li><b>Email:</b> ${cliente.email}</li>
          <li><b>Estado:</b> ${cliente.estado ? 'Activo' : 'Inactivo'}</li>
        </ul>
      `;
      const envioRetiro = orden.envioRetiro;
      const envioRetiroDomElement = `
        <h5 class="card-title">Datos del envio/retiro</h5>
        <ul>
          <li><b>Tipo:</b> ${envioRetiro.tipo}</li>
          <li><b>Costo:</b> ${orden.moneda} ${formatMoney(envioRetiro.costo)}</li>
          <li><b>Estado:</b> ${envioRetiro.estado}</li>
        </ul>
      `;
      const productos = orden.productos;
      let productosDomElement = `
        <h5 class="card-title">Detalle de la orden</h5>
      `;
      if (productos.length > 0) {
        productosDomElement += `
          <ul>
            <li><b>Subtotal:</b> ${orden.moneda} ${formatMoney(orden.subtotal)}</li>
            <li><b>Descuento:</b> ${orden.moneda} ${formatMoney(orden.descuento)}${orden.cupon ? ' <i>[Cupon: '+orden.cupon+']</i>' : ''}</li>
            <li><b>Estado del pago:</b> ${orden.estadoPago}</li>
            <li><b>Items</b><ul>
        `;
        productos.forEach(producto => {
          productosDomElement += `<li><b>Producto #${producto.id}</b><ul>`;
          productosDomElement += `<li><b>SKU:</b> ${producto.SKU}</li>`;
          productosDomElement += `<li><b>Nombre:</b> ${producto.nombre}</li>`;
          productosDomElement += `<li><b>Cantidad:</b> ${producto.cantidad}</li>`;
          productosDomElement += `<li><b>Precio:</b> ${orden.moneda} ${formatMoney(producto.precio)}</li>`;
          productosDomElement += `<li><b>Envio gratis:</b> ${producto.envio_gratis ? 'Si' : 'No'}</li>`;
          productosDomElement += '</ul></li>';
        });
        productosDomElement += '</ul></li></ul>';
      }
      const ordenDomElement = $(`
        <div class="card my-3 orden text-left">
          <h4 class="card-header bg-primary text-white font-weight-bold">
            <span class="float-left">Orden #${orden.id}</span><span class="float-right">Estado: ${orden.estado}</span>
          </h4>
          <div class="card-body row">
            <div class="col-12 col-md-6">
              <div class="row">
                <div class="col-12 pb-5 mb-5">
                  ${clienteDomElement}
                </div>
                <div class="col-12 py-4 border-top datos_envio">
                  ${envioRetiroDomElement}
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 pb-2">
              ${productosDomElement}
            </div>
            <div style="font-size: 1.5em;" class="col-12 text-center font-weight-bold pt-2 border-top">Total: ${orden.moneda} ${formatMoney(orden.total)}</div>
          </div>
          <div class="card-footer text-center bg-white ${orden.isValid ? 'footer_gradient_success' : 'footer_gradient_danger'}">
            ${orden.isValid ? '<span style="font-size: 2em;" class="oi oi-check" title="¡Orden verificada!" aria-hidden="true"></span>' : '<span style="font-size: 2em;" class="oi oi-warning" title="¡Orden erronea!" aria-hidden="true"></span>'}
          </div>
        </div>
      `);
      $(`.section_ordenes`).append(ordenDomElement);
    }
  }
}

/**
 * Este es otro metodo helper que podes usar para darle formato a los valores de moneda de ser necesario.
 * Podes escribir tu propia implementacion o modificar esta si asi lo deseas.
 */
const formatMoney = (n, c = undefined, d = undefined, t = undefined) => {
  let s;
  let i;
  let j;
  c = isNaN(c = Math.abs(c)) ? 2 : c,
  d = d == undefined ? ',' : d,
  t = t == undefined ? '.' : t,
  s = n < 0 ? '-' : '',
  i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
  j = (j = i.length) > 3 ? j % 3 : 0;

  return s + (j ? i.substr(0, j) + t : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + t) + (c ? d + Math.abs(n - +i).toFixed(c).slice(2) : '');
}
