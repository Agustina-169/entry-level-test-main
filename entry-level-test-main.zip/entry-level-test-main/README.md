# Entry level test

Frontend entry level test.

# Instalacion
- git clone repo

# Introduccion
- El objetivo del test es completar los 5 ejercicios presentados en un tiempo maximo de 120 minutos.
- Te recomendamos dar un vistazo general para que puedas calcular cuanto tiempo aproximado podes invertir en cada ejercicio.
  Vos elegis el orden en el que queres resolverlos.
  Es posible que, dependiendo de la velocidad a la que avances, necesites dejar uno o mas ejercicios sin resolucion.
- Los ejercicios tienen distinto peso dentro del resultado final del test, este es el orden de mayor a menor:
  - ejercicio-5
  - ejercicio-2
  - ejercicio-4
  - ejercicio-3
  - ejercicio-1
- Se valorara:
  - Prolijidad
  - Uso de buenas practicas / estandares.
  - El uso de comentarios para explicar el codigo y el proceso de razonamiento utilizado para resolver los problemas.

# Instrucciones
- Vas a encontrar cada ejercicio contenido dentro de su correspondiente carpeta.
- Cada ejercicio posee sus instrucciones en un bloque de comentario ubicado al inicio del archivo 'main.**'.
- Es necesario que al comenzar o antes de finalizar el test:
  - Crees un nuevo branch remoto a partir del main branch.
  - Nombres ese nuevo branch como "{tu-nombre}-{tu-apellido}", por ejemplo: "leren-consulting".
  - Pushees tus cambios a ese nuevo branch.
- Es esperable que hagas varios commits a medida que vayas avanzando en la resolucion de los distintos ejercicios.
- Por favor notificanos por email (a dev@leren.com.ar) cuando termines el test.
  - Usa el asunto: "Leren frontend test".
  - Indicanos en el cuerpo del email el nombre que usaste para tu branch.

# Skills relevantes a evaluar:
- Pensamiento analitico
- Deduccion logica
- Resolucion de problemas
- Habilidad para obtener informacion faltante desde fuentes como Google y/o sitios de documentacion relevante
- Lenguaje JavaScript
- Protocolo HTTP
- HTML
- CSS
- Git

# Feedback
- Cualquier comentario u opinion que tengas respecto de esta experiencia es bienvenido!
