'use strict';
/**********************************************************************************************
Ejercicio 1:

Implementar una funcion con el nombre 'getCantVocales', que:
  - Reciba 1 parametro de tipo string como input.
  - Devuelva el numero entero (recuento) de vocales que contiene ese string ingresado.

Se consideran vocales: a, e, i, o, u.

El string usado como input estara formado unicamente por letras en minuscula [a-z] y/o espacios.

Si lo consideras necesario tambien podes declarar otras funciones para organizar el codigo.
 **********************************************************************************************/

// TODO: tu codigo aca
